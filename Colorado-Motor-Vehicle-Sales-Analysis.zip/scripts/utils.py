import pandas as pd

def add_period_column(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    df['period'] = df['year'].astype(str) + ' Q' + df['quarter'].astype(str)
    return df

def validate_columns(df: pd.DataFrame, required=('year','quarter','county','sales')):
    missing = [c for c in required if c not in df.columns]
    if missing:
        raise ValueError(f"Missing columns: {missing}")
